// Item database for Auction Arena
// Categories: MARVEL, DC, CRICKET, FOOTBALL

const ITEMS = {
  MARVEL: [
    {
      id: "m1",
      name: "Iron Man Mark 85 Helmet",
      category: "MARVEL",
      image: "https://images.unsplash.com/photo-1635805737707-575885ab0820?w=600&h=400&fit=crop",
      description: "Legendary helmet from the final battle. Iconic red & gold.",
      startingPrice: 50
    },
    {
      id: "m2",
      name: "Captain America Shield",
      category: "MARVEL",
      image: "https://images.unsplash.com/photo-1608889825205-eebdb9fc5806?w=600&h=400&fit=crop",
      description: "Vibranium shield. Symbol of justice and freedom.",
      startingPrice: 80
    },
    {
      id: "m3",
      name: "Mjolnir - Thor's Hammer",
      category: "MARVEL",
      image: "https://images.unsplash.com/photo-1612036782180-6f0b6cd846fe?w=600&h=400&fit=crop",
      description: "Only the worthy can lift it. Asgardian power.",
      startingPrice: 120
    },
    {
      id: "m4",
      name: "Spider-Man Web Shooters",
      category: "MARVEL",
      image: "https://images.unsplash.com/photo-1635805737707-575885ab0820?w=600&h=400&fit=crop",
      description: "Peter Parker's signature web-shooting devices.",
      startingPrice: 40
    },
    {
      id: "m5",
      name: "Infinity Gauntlet Replica",
      category: "MARVEL",
      image: "https://images.unsplash.com/photo-1608889825103-eb5ed706fc64?w=600&h=400&fit=crop",
      description: "The ultimate power. Snap of a lifetime.",
      startingPrice: 200
    },
    {
      id: "m6",
      name: "Black Panther Mask",
      category: "MARVEL",
      image: "https://images.unsplash.com/photo-1612036782180-6f0b6cd846fe?w=600&h=400&fit=crop",
      description: "Wakandan technology. Vibranium weave.",
      startingPrice: 90
    }
  ],
  DC: [
    {
      id: "d1",
      name: "Batman Cowl",
      category: "DC",
      image: "https://images.unsplash.com/photo-1608889175250-c3b0c1667d3a?w=600&h=400&fit=crop",
      description: "The Dark Knight's iconic cowl. Justice never sleeps.",
      startingPrice: 100
    },
    {
      id: "d2",
      name: "Superman Cape",
      category: "DC",
      image: "https://images.unsplash.com/photo-1635805737707-575885ab0820?w=600&h=400&fit=crop",
      description: "Red cape of hope. Symbol of the Man of Steel.",
      startingPrice: 70
    },
    {
      id: "d3",
      name: "Wonder Woman Lasso",
      category: "DC",
      image: "https://images.unsplash.com/photo-1608889825205-eebdb9fc5806?w=600&h=400&fit=crop",
      description: "Lasso of Truth. Compels honesty.",
      startingPrice: 85
    },
    {
      id: "d4",
      name: "The Flash Boots",
      category: "DC",
      image: "https://images.unsplash.com/photo-1612036782180-6f0b6cd846fe?w=600&h=400&fit=crop",
      description: "Speed force technology. Faster than light.",
      startingPrice: 60
    },
    {
      id: "d5",
      name: "Green Lantern Ring",
      category: "DC",
      image: "https://images.unsplash.com/photo-1608889825103-eb5ed706fc64?w=600&h=400&fit=crop",
      description: "Willpower made solid. Corps membership.",
      startingPrice: 150
    },
    {
      id: "d6",
      name: "Aquaman Trident",
      category: "DC",
      image: "https://images.unsplash.com/photo-1608889175250-c3b0c1667d3a?w=600&h=400&fit=crop",
      description: "King of Atlantis. Master of the seas.",
      startingPrice: 95
    }
  ],
  CRICKET: [
    {
      id: "c1",
      name: "MS Dhoni Signed Bat",
      category: "CRICKET",
      image: "https://images.unsplash.com/photo-1531415070078-bf7d5e6e80a4?w=600&h=400&fit=crop",
      description: "Helicopter shot legend. Captain Cool's weapon.",
      startingPrice: 110
    },
    {
      id: "c2",
      name: "Virat Kohli Jersey",
      category: "CRICKET",
      image: "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=600&h=400&fit=crop",
      description: "Chase master. King Kohli's match jersey.",
      startingPrice: 90
    },
    {
      id: "c3",
      name: "Sachin Tendulkar Ball",
      category: "CRICKET",
      image: "https://images.unsplash.com/photo-1531415070078-bf7d5e6e80a4?w=600&h=400&fit=crop",
      description: "God of Cricket. 100 international centuries.",
      startingPrice: 130
    },
    {
      id: "c4",
      name: "World Cup 2011 Trophy Replica",
      category: "CRICKET",
      image: "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=600&h=400&fit=crop",
      description: "India's glory night. Dhoni's six.",
      startingPrice: 180
    },
    {
      id: "c5",
      name: "Rohit Sharma Bat",
      category: "CRICKET",
      image: "https://images.unsplash.com/photo-1531415070078-bf7d5e6e80a4?w=600&h=400&fit=crop",
      description: "Hitman. Double century machine.",
      startingPrice: 75
    },
    {
      id: "c6",
      name: "Jasprit Bumrah Jersey",
      category: "CRICKET",
      image: "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=600&h=400&fit=crop",
      description: "Yorker king. Death overs specialist.",
      startingPrice: 65
    }
  ],
  FOOTBALL: [
    {
      id: "f1",
      name: "Lionel Messi Boots",
      category: "FOOTBALL",
      image: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=600&h=400&fit=crop",
      description: "GOAT boots. 8 Ballon d'Or magic.",
      startingPrice: 140
    },
    {
      id: "f2",
      name: "Cristiano Ronaldo Jersey",
      category: "FOOTBALL",
      image: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=600&h=400&fit=crop",
      description: "SIUUU. 5 Champions League titles.",
      startingPrice: 120
    },
    {
      id: "f3",
      name: "World Cup Trophy Replica",
      category: "FOOTBALL",
      image: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=600&h=400&fit=crop",
      description: "The ultimate prize. Every 4 years.",
      startingPrice: 200
    },
    {
      id: "f4",
      name: "Neymar Jr Signed Ball",
      category: "FOOTBALL",
      image: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=600&h=400&fit=crop",
      description: "Brazilian flair. Skills that dazzle.",
      startingPrice: 80
    },
    {
      id: "f5",
      name: "Kylian Mbappé Boots",
      category: "FOOTBALL",
      image: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=600&h=400&fit=crop",
      description: "Speed demon. Future of football.",
      startingPrice: 100
    },
    {
      id: "f6",
      name: "Champions League Ball",
      category: "FOOTBALL",
      image: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=600&h=400&fit=crop",
      description: "European nights. The biggest stage.",
      startingPrice: 90
    }
  ]
};

function getItemsForCategory(category, count = 5) {
  const pool = ITEMS[category] || ITEMS.MARVEL;
  // Shuffle and take required number
  const shuffled = [...pool].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, Math.min(count, shuffled.length));
}

module.exports = { ITEMS, getItemsForCategory };
