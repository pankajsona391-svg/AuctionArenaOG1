const { v4: uuidv4 } = require('uuid');
const { getItemsForCategory } = require('./items');

const ROOMS = new Map(); // roomCode -> Room

function generateJoinCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  // Ensure uniqueness
  if (ROOMS.has(code)) return generateJoinCode();
  return code;
}

function createRoom({ budget, slots, category, playerId, socketId }) {
  if (!playerId || playerId.length < 3 || playerId.length > 16 || !/^[A-Za-z0-9_]+$/.test(playerId)) {
    return { error: 'Invalid Player ID (3-16 chars, letters, numbers, underscore)' };
  }

  const safeBudget = Number(budget);
  const safeSlots = Number(slots);
  const safeCategory = String(category || 'MARVEL').toUpperCase();
  if (!Number.isFinite(safeBudget) || safeBudget < 50 || safeBudget > 100000) return { error: 'Budget must be between ₹50 and ₹100,000' };
  if (![4, 5].includes(safeSlots)) return { error: 'Slots must be 4 or 5' };
  if (!['MARVEL', 'DC', 'CRICKET', 'FOOTBALL'].includes(safeCategory)) return { error: 'Invalid category' };

  const joinCode = generateJoinCode();
  const items = getItemsForCategory(safeCategory, safeSlots);

  const room = {
    joinCode,
    createdAt: Date.now(),
    budget: safeBudget,
    maxSlots: safeSlots,
    category: safeCategory,
    status: 'LOBBY', // LOBBY | AUCTION | RESULT
    players: {
      [playerId]: {
        id: playerId,
        socketId,
        isHost: true,
        balance: safeBudget,
        slotsUsed: 0,
        itemsWon: [],
        ready: true,
        connected: true
      }
    },
    playerOrder: [playerId],
    items,
    currentItemIndex: -1,
    currentBid: 0,
    highestBidder: null,
    lastBid: null, // { playerId, amount }
    auctionState: 'IDLE', // IDLE | INTRO | BIDDING | GOING_ONCE | GOING_TWICE | SOLD | NEXT
    auctionTimer: 0,
    timerInterval: null,
    winner: null,
    results: null
  };

  ROOMS.set(joinCode, room);
  return { room, joinCode };
}

function joinRoom({ joinCode, playerId, socketId }) {
  const room = ROOMS.get(joinCode?.toUpperCase());
  if (!room) return { error: 'Room not found' };
  if (room.status !== 'LOBBY') return { error: 'Game already started' };
  if (Object.keys(room.players).length >= 2) return { error: 'Room is full (max 2 players)' };

  if (!playerId || playerId.length < 3 || playerId.length > 16 || !/^[A-Za-z0-9_]+$/.test(playerId)) {
    return { error: 'Invalid Player ID (3-16 chars, letters, numbers, underscore)' };
  }

  if (room.players[playerId]) {
    return { error: 'Player ID already taken in this room' };
  }

  room.players[playerId] = {
    id: playerId,
    socketId,
    isHost: false,
    balance: room.budget,
    slotsUsed: 0,
    itemsWon: [],
    ready: true,
    connected: true
  };
  room.playerOrder.push(playerId);

  return { room };
}

function getPublicRoomState(room) {
  if (!room) return null;
  return {
    joinCode: room.joinCode,
    status: room.status,
    budget: room.budget,
    maxSlots: room.maxSlots,
    category: room.category,
    players: Object.values(room.players).map(p => ({
      id: p.id,
      isHost: p.isHost,
      balance: p.balance,
      slotsUsed: p.slotsUsed,
      itemsWon: p.itemsWon,
      ready: p.ready,
      connected: p.connected
    })),
    playerOrder: room.playerOrder,
    currentItemIndex: room.currentItemIndex,
    currentItem: room.currentItemIndex >= 0 ? room.items[room.currentItemIndex] : null,
    currentBid: room.currentBid,
    highestBidder: room.highestBidder,
    lastBid: room.lastBid,
    auctionState: room.auctionState,
    auctionTimer: room.auctionTimer,
    winner: room.winner,
    results: room.results,
    totalItems: room.items.length
  };
}

function placeBid(room, playerId, amount) {
  if (!room || room.status !== 'AUCTION') return { error: 'Auction not active' };
  if (room.auctionState !== 'BIDDING' && room.auctionState !== 'GOING_ONCE' && room.auctionState !== 'GOING_TWICE') {
    return { error: 'Bidding not open' };
  }

  const player = room.players[playerId];
  if (!player) return { error: 'Player not found' };
  if (!player.connected) return { error: 'Player disconnected' };
  if (player.slotsUsed >= room.maxSlots) return { error: 'SLOTS FULL' };
  if (!Number.isInteger(amount) || amount <= 0) return { error: 'Invalid bid amount' };

  // Additive auction: every click increases the shared total.
  // The next total must be affordable by the player making the click,
  // because the highest bidder pays the complete final total if they win.
  const nextBid = room.currentBid + amount;
  if (nextBid > player.balance) return { error: `Bid would exceed your ₹${player.balance} budget` };
  room.currentBid = nextBid;
  room.highestBidder = playerId;
  room.lastBid = { playerId, amount };

  // Reset timer on new bid (gives more time)
  room.auctionTimer = Math.max(room.auctionTimer, 12);
  room.auctionState = 'BIDDING';

  return { success: true, currentBid: room.currentBid, highestBidder: playerId };
}

function startAuctionPhase(room, io) {
  if (room.currentItemIndex >= room.items.length) {
    // Game over
    finishGame(room, io);
    return;
  }

  room.currentBid = 0;
  room.highestBidder = null;
  room.lastBid = null;
  room.auctionState = 'INTRO';
  room.auctionTimer = 3; // intro seconds

  broadcast(room, io, 'auction_state', getPublicRoomState(room));

  // After intro → start bidding
  setTimeout(() => {
    if (!ROOMS.has(room.joinCode)) return;
    room.auctionState = 'BIDDING';
    room.auctionTimer = 20; // 20 seconds bidding window
    broadcast(room, io, 'auction_state', getPublicRoomState(room));
    startTimer(room, io);
  }, 3000);
}

function startTimer(room, io) {
  if (room.timerInterval) clearInterval(room.timerInterval);

  room.timerInterval = setInterval(() => {
    if (!ROOMS.has(room.joinCode)) {
      clearInterval(room.timerInterval);
      return;
    }

    room.auctionTimer -= 1;

    if (room.auctionTimer <= 0) {
      clearInterval(room.timerInterval);
      room.timerInterval = null;

      if (room.auctionState === 'BIDDING') {
        room.auctionState = 'GOING_ONCE';
        room.auctionTimer = 3;
        broadcast(room, io, 'auction_state', getPublicRoomState(room));
        startTimer(room, io);
      } else if (room.auctionState === 'GOING_ONCE') {
        room.auctionState = 'GOING_TWICE';
        room.auctionTimer = 3;
        broadcast(room, io, 'auction_state', getPublicRoomState(room));
        startTimer(room, io);
      } else if (room.auctionState === 'GOING_TWICE') {
        // SOLD
        room.auctionState = 'SOLD';
        settleAuction(room, io);
      }
    } else {
      broadcast(room, io, 'auction_tick', {
        auctionTimer: room.auctionTimer,
        auctionState: room.auctionState,
        currentBid: room.currentBid,
        highestBidder: room.highestBidder
      });
    }
  }, 1000);
}

function settleAuction(room, io) {
  const item = room.items[room.currentItemIndex];
  let winnerId = room.highestBidder;

  if (winnerId && room.players[winnerId]) {
    const winner = room.players[winnerId];
    // Deduct money (server authoritative)
    const finalPrice = room.currentBid;
    if (winner.balance >= finalPrice) {
      winner.balance -= finalPrice;
      winner.slotsUsed += 1;
      winner.itemsWon.push({
        ...item,
        wonFor: finalPrice
      });
    } else {
      // Safety: should never happen due to validation
      winnerId = null;
    }
  }

  room.winner = winnerId;

  broadcast(room, io, 'auction_end', {
    ...getPublicRoomState(room),
    soldTo: winnerId,
    soldPrice: room.currentBid,
    item
  });

  // Wait 4 seconds then next item
  setTimeout(() => {
    if (!ROOMS.has(room.joinCode)) return;
    room.currentItemIndex += 1;
    room.auctionState = 'NEXT';
    if (room.currentItemIndex >= room.items.length) {
      finishGame(room, io);
    } else {
      startAuctionPhase(room, io);
    }
  }, 4000);
}

function finishGame(room, io) {
  room.status = 'RESULT';
  room.auctionState = 'IDLE';

  // Calculate results
  const results = Object.values(room.players).map(p => ({
    id: p.id,
    itemsWon: p.itemsWon.length,
    moneySpent: room.budget - p.balance,
    remaining: p.balance,
    items: p.itemsWon
  }));

  // Winner = most items, tie-breaker = least money spent
  results.sort((a, b) => {
    if (b.itemsWon !== a.itemsWon) return b.itemsWon - a.itemsWon;
    return a.moneySpent - b.moneySpent;
  });

  room.results = results;
  room.winner = results[0]?.id || null;

  broadcast(room, io, 'game_result', getPublicRoomState(room));
}

function broadcast(room, io, event, data) {
  Object.values(room.players).forEach(p => {
    if (p.socketId && p.connected) {
      io.to(p.socketId).emit(event, data);
    }
  });
}

function cleanupOldRooms() {
  const now = Date.now();
  for (const [code, room] of ROOMS.entries()) {
    // Remove rooms older than 2 hours
    if (now - room.createdAt > 2 * 60 * 60 * 1000) {
      if (room.timerInterval) clearInterval(room.timerInterval);
      ROOMS.delete(code);
    }
  }
}

setInterval(cleanupOldRooms, 10 * 60 * 1000);

module.exports = {
  ROOMS,
  createRoom,
  joinRoom,
  getPublicRoomState,
  placeBid,
  startAuctionPhase,
  broadcast
};
