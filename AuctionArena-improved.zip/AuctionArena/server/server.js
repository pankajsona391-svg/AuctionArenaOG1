const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const {
  createRoom,
  joinRoom,
  getPublicRoomState,
  placeBid,
  startAuctionPhase,
  ROOMS,
  broadcast
} = require('./rooms');

const app = express();
app.use(cors());
app.use(express.json());

// Serve static frontend
const path = require('path');
app.use(express.static(path.join(__dirname, 'public')));

app.get('/health', (req, res) => {
  res.json({ status: 'ok', rooms: ROOMS.size, time: new Date().toISOString() });
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);

  socket.on('create_room', (data, callback) => {
    const { budget, slots, category, playerId } = data || {};
    const result = createRoom({ budget, slots, category, playerId, socketId: socket.id });
    if (result.error) {
      if (typeof callback === 'function') callback({ error: result.error });
      return;
    }
    socket.join(result.joinCode);
    socket.roomCode = result.joinCode;
    socket.playerId = playerId;
    if (typeof callback === 'function') {
      callback({ success: true, joinCode: result.joinCode, room: getPublicRoomState(result.room) });
    }
    console.log(`Room created: ${result.joinCode} by ${playerId}`);
  });

  socket.on('join_room', (data, callback) => {
    const { joinCode, playerId } = data || {};
    const result = joinRoom({ joinCode, playerId, socketId: socket.id });
    if (result.error) {
      if (typeof callback === 'function') callback({ error: result.error });
      return;
    }
    socket.join(joinCode.toUpperCase());
    socket.roomCode = joinCode.toUpperCase();
    socket.playerId = playerId;

    // Notify everyone in the room
    const publicState = getPublicRoomState(result.room);
    io.to(joinCode.toUpperCase()).emit('player_joined', publicState);

    if (typeof callback === 'function') {
      callback({ success: true, room: publicState });
    }
    console.log(`${playerId} joined room ${joinCode}`);
  });

  socket.on('start_game', (data, callback) => {
    const room = ROOMS.get(socket.roomCode);
    if (!room) {
      if (typeof callback === 'function') callback({ error: 'Room not found' });
      return;
    }
    const player = room.players[socket.playerId];
    if (!player || !player.isHost) {
      if (typeof callback === 'function') callback({ error: 'Only host can start the game' });
      return;
    }
    if (Object.keys(room.players).length < 2) {
      if (typeof callback === 'function') callback({ error: 'Need 2 players to start' });
      return;
    }
    if (Object.values(room.players).some(p => !p.connected)) {
      if (typeof callback === 'function') callback({ error: 'Both players must be connected' });
      return;
    }

    room.status = 'AUCTION';
    room.currentItemIndex = 0;
    startAuctionPhase(room, io);

    if (typeof callback === 'function') callback({ success: true });
    console.log(`Game started in room ${room.joinCode}`);
  });

  socket.on('place_bid', (data, callback) => {
    const room = ROOMS.get(socket.roomCode);
    if (!room) {
      if (typeof callback === 'function') callback({ error: 'Room not found' });
      return;
    }
    const amount = Number(data?.amount);
    if (!amount || amount <= 0) {
      if (typeof callback === 'function') callback({ error: 'Invalid amount' });
      return;
    }

    const result = placeBid(room, socket.playerId, amount);
    if (result.error) {
      if (typeof callback === 'function') callback({ error: result.error });
      return;
    }

    // Broadcast new bid state to both players
    broadcast(room, io, 'bid_update', {
      currentBid: room.currentBid,
      highestBidder: room.highestBidder,
      lastBid: room.lastBid,
      auctionTimer: room.auctionTimer,
      players: getPublicRoomState(room).players
    });

    if (typeof callback === 'function') {
      callback({ success: true, currentBid: room.currentBid });
    }
  });

  socket.on('reconnect_player', (data, callback) => {
    const { joinCode, playerId } = data || {};
    const room = ROOMS.get(joinCode?.toUpperCase());
    if (!room) {
      if (typeof callback === 'function') callback({ error: 'Room not found' });
      return;
    }
    const player = room.players[playerId];
    if (!player) {
      if (typeof callback === 'function') callback({ error: 'Player not in room' });
      return;
    }

    // Update socket
    player.socketId = socket.id;
    player.connected = true;
    socket.join(joinCode.toUpperCase());
    socket.roomCode = joinCode.toUpperCase();
    socket.playerId = playerId;

    if (typeof callback === 'function') {
      callback({ success: true, room: getPublicRoomState(room) });
    }
    broadcast(room, io, 'player_reconnected', getPublicRoomState(room));
    console.log(`${playerId} reconnected to ${joinCode}`);
  });

  socket.on('leave_room', () => {
    handleDisconnect(socket);
  });

  socket.on('disconnect', () => {
    handleDisconnect(socket);
  });

  function handleDisconnect(sock) {
    const room = ROOMS.get(sock.roomCode);
    if (!room) return;
    const player = room.players[sock.playerId];
    if (player && player.socketId === sock.id) {
      player.connected = false;
      console.log(`${sock.playerId} disconnected from ${sock.roomCode}`);
      broadcast(room, io, 'player_disconnected', getPublicRoomState(room));
    }
  }
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Auction Arena server running on port ${PORT}`);
});
