# AUCTION ARENA

**2-player real-time auction game** — mobile-first web app + Android WebView shell.

## Core gameplay

- Exactly **2 human players**; the game acts as the auctioneer/host.
- Separate **Player ID** and **6-character Join Code**.
- Categories: **Marvel, DC, Cricket, Football**.
- Select **₹100 / ₹500 / ₹1,000 / ₹5,000 / ₹10,000 / Custom** starting budget.
- Select **4 or 5 slots**.
- Every auction item has an image, name, description and starting-price metadata.
- Server-authoritative timer, balance, slots, winner and room state.
- Additive bidding: **+₹10 → +₹2 = ₹12 → +₹2 = ₹14 → +₹2 = ₹16**.
- Each phone shows only its own control panel and balance; there is no opponent bid panel.
- Auction stage with a visual auctioneer, gavel announcements and device text-to-speech.
- Reconnect support using the saved room/player session.
- Results are synchronized to both phones.

## 1. Deploy the multiplayer server

The server is under `server/` and already serves the frontend from `server/public/`.

### Render

The repository includes `render.yaml`.

After connecting the repository to Render, the service uses:

- Root directory: `server`
- Build command: `npm install`
- Start command: `node server.js`
- Health check: `/health`

Copy the public HTTPS URL after deployment.

## 2. Point the Android app at the server

Open:

`android/app/src/main/java/com/auctionarena/live/MainActivity.kt`

Change:

`SERVER_URL`

to the Render/Railway/etc. HTTPS URL.

## 3. Build the APK with GitHub Actions

The repository contains:

`.github/workflows/build-apk.yml`

In GitHub:

1. Open **Actions**.
2. Select **Build Auction Arena APK**.
3. Click **Run workflow**.
4. Wait for the green check.
5. Open the completed workflow run.
6. Download the **AuctionArena-debug-apk** artifact.

The workflow uses Gradle 8.7 + Java 17 and builds `app-debug.apk`.

## 4. Two-phone test

1. Install/open the APK on Phone 1.
2. Enter a Player ID.
3. Choose budget, slots and category.
4. Tap **CREATE GAME**.
5. Share the 6-character Join Code.
6. Phone 2 enters the Join Code and its own Player ID.
7. Host taps **START AUCTION**.
8. Both phones should show the same item, timer and current total bid.
9. Test additive bidding: `+₹10`, then the other phone `+₹2`, then `+₹2` → **₹14**.
10. Test reconnect by temporarily switching network off/on.

## Project structure

```text
AuctionArena/
├── server/
│   ├── server.js
│   ├── rooms.js
│   ├── items.js
│   └── public/
│       ├── index.html
│       ├── styles.css
│       └── app.js
├── android/
│   └── app/
│       └── src/main/...
├── .github/workflows/build-apk.yml
└── render.yaml
```

## Important

The server is authoritative. A client cannot simply change its own balance or bypass the additive-bid affordability check. Rooms are currently in-memory, so a server restart clears active rooms.
